#!/bin/bash

<<task
Скрипт устанавливает nginx и запускает его на порт 81

При входе на $IP:81/test перенаправляет на google.com

Добавить в автозагрузку

Запретить его обновление
task

#1.1 install and config
yum -y install nginx

#1.2 create /etc/nginx/conf.d/default.conf
echo "
server {
    listen       81 default_server;
    listen       [::]:81 default_server;
    server_name  _;
    root         /usr/share/nginx/html;

    # Load configuration files for the default server block.
    include /etc/nginx/default.d/*.conf;

    location / {
    }

    location /test {
            rewrite ^/test(.*)$ https://www.google.com/$1 redirect;
    }

    error_page 404 /404.html;
        location = /40x.html {
    }

    error_page 500 502 503 504 /50x.html;
        location = /50x.html {
    }
}" > /etc/nginx/conf.d/default.conf
#sed -i 's/80/81/g' /etc/nginx/nginx.conf

#1.3 start nginx
systemctl start nginx

#1.4 config firewall
#firewall-cmd --permanent --zone=public --add-port=80/tcp
firewall-cmd --permanent --zone=public --add-port=81/tcp
firewall-cmd --reload
#systemctl restart nginx

#3 ensble autostart
systemctl enable nginx

#4 disable update
echo exclude=nginx* >> /etc/yum.conf
