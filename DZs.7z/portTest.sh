#!/bin/bash

<< task
Скрипт принимает на вход 1 параметр (номер порта)

Проверяет не занят ли этот порт и выводит соответствующее сообшение

Метод1 открывает порт средствами nc (netcat)

Метод2 проверяет что порт открыт
task

#1 receive port number 
port=$1

#3 open port
function openPort {
	nc -l $port 2> /dev/null
	sleep 3
}

#4 check port if open
function testPort (){
	check2=$(lsof -i:$port | awk '{print $10}')
	if [ -z "$check2" ];  then
        	echo "Port $port not opened"
	else
        	echo "Port $port opened"
	fi
}

#2 check port if free (if free then open)
check1=$(lsof -i:$port | awk '{print $10}')
if [ -z "$check1" ];  then
	echo "Port $port is free"
	openPort &
else
        echo "Port $port is not free"
	exit 0
fi
testPort
