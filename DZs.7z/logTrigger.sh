#!/bin/bash
function metod1 {
	out=0	
	error=0
	t1=$(stat /var/log/messages | grep Modify | awk '{print $3}' | awk -F. '{print $1}')
	sleep 1
	while [ $out != "DONE" ]
	do
	out=$(tail -n 1 /var/log/messages)
	t2=$(stat /var/log/messages | grep Modify | awk '{print $3}' | awk -F. '{print $1}')
		if [ $t2 != $t1 ]; then
			case "$out" in
			[0-3]) echo -e "\033[1;32m $out-OK";;
			[4-7]) echo -e "\033[1;33m $out-WARNING";;
			[8-9]|10) echo -e "\033[1;31m $out-ERROR"; error=$[$error+1];;
			esac
		t1=$t2
		fi
	sleep 1
	done
	echo  -e "\033[1;37m $out-Errors count is $error"
}
function metod2 {
for (( i=1; i<=12; i++ ))
	do
		number=$(shuf -i 0-10 -n1)
    		echo $number >> /var/log/messages
		sleep 5
	done
echo "DONE" >> /var/log/messages
}
metod2 &
metod1
