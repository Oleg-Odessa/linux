#!/bin/bash

opendnsname=( google cisco cloudflare quad4 )
opendnsip=( 8.8.8.8 208.67.220.220 1.1.1.1 9.9.9.9)


for (( i=0; i<=3; i++ ))
	do
	echo "Do mtr request to ${opendnsname[i]} ${opendnsip[i]}"
	mtr -i 0.1 -c 100  --report "${opendnsip[i]}" > "${opendnsname[i]}"
	done
echo -e "\033[1;33m mrt reports were created with next parametrs: interval 0.1 sec, number of packeges 100 "
