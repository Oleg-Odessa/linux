#!/bin/bash

#######
set -o pipefail
#######

cat /etc/passwd | grep -B 10 root | tr ":" " " | QWE | cut -d "/" -f1 | awk '{ print $NF }' | wc -l

exitcode=$?

echo "exit with ${exitcode}"

exit ${exitcode}
